# 토익 다의어 판별기

## 실행 방법
1. 이 폴더에 `model.pkl` 파일이 있는지 확인하세요.
2. 필요한 패키지를 설치하세요: `pip install -r requirements.txt`
3. 프로그램을 실행하세요: `python main.py`

## 사용법
- 영어 문장과 타겟 단어를 입력하면 AI가 문맥을 분석해 의미를 알려줍니다.