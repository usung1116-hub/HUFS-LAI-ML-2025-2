import joblib
import os
import sys

MODEL_FILE = 'model.pkl'

# 단어별 의미 사전
MEANING_MAP = {
    'address': {0: '주소 (Noun)', 1: '다루다/연설하다 (Verb)'},
    'account': {0: '계좌/계정 (Noun)', 1: '설명하다 (Verb)'},
    'present': {0: '선물 (Noun)', 1: '발표하다/제시하다 (Verb)'},
    'contract': {0: '계약서 (Noun)', 1: '병에 걸리다/수축하다 (Verb)'},
    'appreciate': {0: '고마워하다 (Verb)', 1: '진가를 알다/가치 상승 (Verb)'}
}

def load_model():
    if not os.path.exists(MODEL_FILE):
        print(f"❌ 오류: '{MODEL_FILE}' 파일이 없습니다.")
        sys.exit(1)
    print("⏳ 모델 로딩 중...", end="")
    try:
        model = joblib.load(MODEL_FILE)
        print(" 완료! ✅")
        return model
    except Exception as e:
        print(f"\n❌ 모델 로드 실패: {e}")
        sys.exit(1)

def predict(model):
    print("\n" + "="*50)
    print("   [토익 빈출 다의어 의미 판별기]")
    print("="*50)
    print("종료하려면 'q'를 입력하세요.\n")

    while True:
        sentence = input("영어 문장 입력: ").strip()
        if sentence.lower() in ['q', 'quit', 'exit']:
            print("\n👋 종료합니다.")
            break
        if not sentence: continue

        target_word = input("타겟 단어 입력: ").strip().lower()
        if not target_word: continue

        try:
            # 예측
            prediction = model.predict([sentence])[0]
            proba = model.predict_proba([sentence])[0][prediction] * 100
            
            # 단어별 맞춤 의미 찾기
            if target_word in MEANING_MAP:
                meaning = MEANING_MAP[target_word][prediction]
            else:
                # 목록에 없는 단어일 경우 기본값
                meaning = "Label 0 (명사/제1의미)" if prediction == 0 else "Label 1 (동사/제2의미)"

            print(f"\n👉 분석 결과: {meaning}")
            print(f"📊 확신도: {proba:.2f}%")
            print("-" * 50)
            
        except Exception as e:
            print(f"❌ 오류: {e}")

if __name__ == "__main__":
    model = load_model()
    predict(model)